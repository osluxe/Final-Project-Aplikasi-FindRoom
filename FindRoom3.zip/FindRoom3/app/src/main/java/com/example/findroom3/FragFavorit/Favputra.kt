package com.example.findroom1

import android.annotation.SuppressLint
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteDatabase.openOrCreateDatabase
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.findroom1.Favputra_Item
import com.example.findroom3.R

class Favputra : Fragment() {

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.frag_favputra, container, false)

        val rv_favputra: RecyclerView = view.findViewById(R.id.rv_favputra)


        val nama: MutableList<String> = mutableListOf()
        nama.add("Kost Barokah")
        val kategori: MutableList<String> = mutableListOf()
        kategori.add("Putra")
        val alamat: MutableList<String> = mutableListOf()
        alamat.add("Jl. Wijaya Kusuma, Perumnas, Condong Catur")
        val harga: MutableList<String> = mutableListOf()
        harga.add("Rp. 7.500.000/Thn")
        val fasilitas: MutableList<String> = mutableListOf()
        fasilitas.add("Lemasri, Kasur, Wifi, Laundry")
        val foto: MutableList<Int> = mutableListOf()
        foto.add(R.drawable.kost)


        val fi = Favputra_Item(nama, kategori, alamat, harga, fasilitas, foto)
        rv_favputra.adapter = fi
        rv_favputra.layoutManager = LinearLayoutManager(requireContext())

        return view
    }
}
