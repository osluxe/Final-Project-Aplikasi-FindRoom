package com.example.findroom3

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class Profil : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.profil, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //tampilan nama user
        val username:TextView = view.findViewById(R.id.username)

        //dapatkan data user untuk menghapus tiket
        val tiket: SharedPreferences = requireContext().getSharedPreferences("user", AppCompatActivity.MODE_PRIVATE)
        val idUserLogin: String? = tiket.getString("username", "").toString().trim()
        username.text = idUserLogin

        // Buka database
        val dbkampus: SQLiteDatabase = requireContext().openOrCreateDatabase("findroom", Context.MODE_PRIVATE, null)

        //Gunakan parameterized query untuk menghindari SQL injection
        val query = "SELECT username FROM user WHERE id_user = ?"
        val args = arrayOf(idUserLogin)
        val cursor = dbkampus.rawQuery(query, args)

        //button
        val kost_saya:LinearLayout = view.findViewById(R.id.kost_saya)
        val btn_logout:LinearLayout = view.findViewById(R.id.btn_logout)

        btn_logout.setOnClickListener {
            val edittiket = tiket.edit()
            edittiket.clear()
            edittiket.commit()

            val keluar: Intent = Intent(requireContext(), Login::class.java)
            startActivity(keluar)
            requireActivity().finishAffinity()
        }

        kost_saya.setOnClickListener {
            val pindah: Intent = Intent(requireContext(), MyKost::class.java)
            startActivity(pindah)
        }
    }
}