package com.example.findroom3.FragFavorit

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.cardview.widget.CardView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentContainerView
import com.example.findroom1.Favcampur
import com.example.findroom1.Favputra
import com.example.findroom1.Favputri
import com.example.findroom3.R

class Favorit : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.favorit, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val btn_favputra: CardView = view.findViewById(R.id.btn_favputra)
        val btn_favcampur: CardView = view.findViewById(R.id.btn_favcampur)
        val btn_favputri: CardView = view.findViewById(R.id.btn_favputri)
        val fc_konten: FragmentContainerView = view.findViewById(R.id.fc_kontenf)

        val fm = requireActivity().supportFragmentManager
        val ft = fm.beginTransaction()
        ft.replace(fc_konten.id, Favputra())
        ft.commit()

        btn_favputra.setOnClickListener {
            val fm = requireActivity().supportFragmentManager
            val ft = fm.beginTransaction()
            ft.replace(fc_konten.id, Favputra())
            ft.commit()
        }

        btn_favcampur.setOnClickListener {
            val fm = requireActivity().supportFragmentManager
            val ft = fm.beginTransaction()
            ft.replace(fc_konten.id, Favcampur())
            ft.commit()
        }

        btn_favputri.setOnClickListener {
            val fm = requireActivity().supportFragmentManager
            val ft = fm.beginTransaction()
            ft.replace(fc_konten.id, Favputri())
            ft.commit()
        }
    }
}
