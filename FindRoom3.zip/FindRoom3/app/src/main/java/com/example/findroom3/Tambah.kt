package com.example.findroom3

import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.content.SharedPreferences
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout

class Tambah : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.tambah, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val txt_namakost: EditText = view.findViewById(R.id.txt_namakost)
        val txt_kategorikost: EditText = view.findViewById(R.id.txt_kategorikost)
        val txt_alamatkost: EditText = view.findViewById(R.id.txt_alamatkost)
        val txt_hargakost: EditText = view.findViewById(R.id.txt_hargakost)
        val txt_fasilitaskost: EditText = view.findViewById(R.id.txt_fasilitaskost)
        val btn_upload: LinearLayout = view.findViewById(R.id.btn_upload)

        // Dapatkan id_user yang sedang login dari SharedPreferences
        val session: SharedPreferences = requireContext().getSharedPreferences("user", Context.MODE_PRIVATE)
        val idUserLogin: String? = session.getString("id_user", "")

        //btn simpan ditekan
        btn_upload.setOnClickListener {
            val isi_namakost: String = txt_namakost.text.toString()
            val isi_kategorikost: String = txt_kategorikost.text.toString()
            val isi_alamatkost: String = txt_alamatkost.text.toString()
            val isi_hargakost: String = txt_hargakost.text.toString()
            val isi_fasilitaskost: String = txt_fasilitaskost.text.toString()

            val dbkost: SQLiteDatabase = requireContext().openOrCreateDatabase(
                "findroom",
                Context.MODE_PRIVATE, null
            )

            // Gunakan parameterized query untuk menghindari SQL injection
            val query =
                "INSERT INTO kost(nama_kost, kategori_kost, alamat_kost, harga_kost, fasilitas_kost, id_user) " +
                        "VALUES(?, ?, ?, ?, ?, ?)"
            val args = arrayOf(isi_namakost, isi_kategorikost, isi_alamatkost, isi_hargakost, isi_fasilitaskost, idUserLogin)
            dbkost.execSQL(query, args)

            val pindah = Intent(requireContext(), MyKost::class.java)
            startActivity(pindah)

        }
    }
}
