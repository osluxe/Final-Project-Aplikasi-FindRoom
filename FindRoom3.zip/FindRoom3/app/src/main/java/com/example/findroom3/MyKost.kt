package com.example.findroom3

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.widget.ImageView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.findroom3.Fraghome.Home_Item

class MyKost : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.my_kost)
        val rv_mykost: RecyclerView = findViewById(R.id.rv_mykost)

        val id: MutableList<String> = mutableListOf()
        val nama: MutableList<String> = mutableListOf()
        val kategori: MutableList<String> = mutableListOf()
        val alamat: MutableList<String> = mutableListOf()
        val harga: MutableList<String> = mutableListOf()
        val fasilitas: MutableList<String> = mutableListOf()
        val iduser: MutableList<String> = mutableListOf()
        val foto: MutableList<Int> = mutableListOf()

        // Dapatkan id_user yang sedang login dari SharedPreferences
        val session: SharedPreferences = getSharedPreferences("user", MODE_PRIVATE)
        val idUserLogin: String? = session.getString("id_user", "")

        // Buka database
        val dbkampus: SQLiteDatabase = openOrCreateDatabase("findroom", Context.MODE_PRIVATE, null)

        // Gunakan parameterized query untuk menghindari SQL injection
        val query = "SELECT * FROM kost WHERE id_user = ?"
        val args = arrayOf(idUserLogin)
        val gali_kost = dbkampus.rawQuery(query, args)


        while (gali_kost.moveToNext())
        {
            id.add(gali_kost.getString(0))
            nama.add(gali_kost.getString(1))
            kategori.add(gali_kost.getString(2))
            alamat.add(gali_kost.getString(3))
            harga.add(gali_kost.getString(4))
            fasilitas.add(gali_kost.getString(5))
            iduser.add(gali_kost.getString(6))
            foto.add(R.drawable.kost)

        }


        val fi = MyKost_Item(this, id, nama, kategori,  alamat, harga, fasilitas,iduser, foto)
        rv_mykost.adapter = fi
        rv_mykost.layoutManager = LinearLayoutManager(this)

        val btn_back: ImageView = findViewById(R.id.btn_back)
        btn_back.setOnClickListener {
            val pindah: Intent = Intent(this, Utama::class.java)
            startActivity(pindah)
        }
    }
}
