package com.example.findroom1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.findroom3.R

class Favputra_Item(val nama:MutableList<String>, val kategori:MutableList<String>, val alamat:MutableList<String>, val harga:MutableList<String>, val fasilitas:MutableList<String>, val foto:MutableList<Int>) : RecyclerView.Adapter<Favputra_Item.ViewHolder>(){
    //dapatkan layout
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Favputra_Item.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.favputra_item, parent, false)
        return ViewHolder(view)
    }

    class ViewHolder (ItemView: View) : RecyclerView.ViewHolder(ItemView){
        val nm_kost:TextView = ItemView.findViewById(R.id.nm_kost)
        val kt_kost:TextView = ItemView.findViewById(R.id.kt_kost)
        val alamat_kost:TextView = ItemView.findViewById(R.id.alamat_kost)
        val harga_kost:TextView = ItemView.findViewById(R.id.harga_kost)
        val fasilitas_kost:TextView = ItemView.findViewById(R.id.fasilitas_kost)
        val foto_kost:ImageView = ItemView.findViewById(R.id.foto_kost)

    }

    override fun getItemCount(): Int {
        return nama.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.nm_kost.text = nama.get(position)
        holder.kt_kost.text = kategori.get(position)
        holder.alamat_kost.text = alamat.get(position)
        holder.harga_kost.text = harga.get(position)
        holder.fasilitas_kost.text = fasilitas.get(position)
        holder.foto_kost.setImageResource(foto.get(position))
    }
}