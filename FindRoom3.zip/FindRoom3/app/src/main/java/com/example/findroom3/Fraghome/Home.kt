package com.example.findroom3

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.cardview.widget.CardView
import androidx.fragment.app.FragmentContainerView
import com.example.findroom1.Favcampur
import com.example.findroom1.Favputra
import com.example.findroom1.Favputri
import com.example.findroom3.Fraghome.Homecampur
import com.example.findroom3.Fraghome.Homeputra
import com.example.findroom3.Fraghome.Homeputri

class Home : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val btn_filterputra: CardView = view.findViewById(R.id.btn_filterputra)
        val btn_filtercampur: CardView = view.findViewById(R.id.btn_filtercampur)
        val btn_filterputri: CardView = view.findViewById(R.id.btn_filterputri)
        val fc_konten: FragmentContainerView = view.findViewById(R.id.rv_home)

        val fm = requireActivity().supportFragmentManager
        val ft = fm.beginTransaction()
        ft.replace(fc_konten.id, Homeputra())
        ft.commit()

        btn_filterputra.setOnClickListener {
            val fm = requireActivity().supportFragmentManager
            val ft = fm.beginTransaction()
            ft.replace(fc_konten.id, Homeputra())
            ft.commit()
        }

        btn_filtercampur.setOnClickListener {
            val fm = requireActivity().supportFragmentManager
            val ft = fm.beginTransaction()
            ft.replace(fc_konten.id, Homecampur())
            ft.commit()
        }

        btn_filterputri.setOnClickListener {
            val fm = requireActivity().supportFragmentManager
            val ft = fm.beginTransaction()
            ft.replace(fc_konten.id, Homeputri())
            ft.commit()
        }
    }
}