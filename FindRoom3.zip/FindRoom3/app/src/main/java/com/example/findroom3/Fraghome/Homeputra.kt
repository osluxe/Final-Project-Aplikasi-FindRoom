package com.example.findroom3.Fraghome

import android.annotation.SuppressLint
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.findroom3.R

class Homeputra : Fragment() {
    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.frag_homeputra, container, false)

        val rv_favputra: RecyclerView = view.findViewById(R.id.rv_homeputra)

        val id: MutableList<String> = mutableListOf()
        val nama: MutableList<String> = mutableListOf()
        val kategori: MutableList<String> = mutableListOf()
        val alamat: MutableList<String> = mutableListOf()
        val harga: MutableList<String> = mutableListOf()
        val fasilitas: MutableList<String> = mutableListOf()
        val iduser: MutableList<String> = mutableListOf()
        val foto: MutableList<Int> = mutableListOf()

        val dbkampus: SQLiteDatabase = requireContext().openOrCreateDatabase("findroom", Context.MODE_PRIVATE, null)

        val gali_kost = dbkampus.rawQuery("select * from kost where kategori_kost = 'Putra'", null)

        while (gali_kost.moveToNext())
        {
            id.add(gali_kost.getString(0))
            nama.add(gali_kost.getString(1))
            kategori.add(gali_kost.getString(2))
            alamat.add(gali_kost.getString(3))
            harga.add(gali_kost.getString(4))
            fasilitas.add(gali_kost.getString(5))
            iduser.add(gali_kost.getString(6))
            foto.add(R.drawable.kost)

        }

        val fi = Home_Item(id, nama, kategori, alamat, harga, fasilitas,iduser, foto)
        rv_favputra.adapter = fi
        rv_favputra.layoutManager = LinearLayoutManager(requireContext())

        return view
    }
}