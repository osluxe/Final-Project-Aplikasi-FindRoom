package com.example.findroom3

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast

class Login : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)

        val edt_username:EditText = findViewById(R.id.edt_username)
        val edt_password:EditText = findViewById(R.id.edt_password)
        val btn_login:LinearLayout = findViewById(R.id.btn_login)

        btn_login.setOnClickListener {
            //dapatkan username dan password dari editText Login
            val isi_username:String = edt_username.text.toString()
            val isi_password:String = edt_password.text.toString()

            //konek ke database
            val dbkost: SQLiteDatabase = openOrCreateDatabase("findroom", MODE_PRIVATE, null)

            //cek tabel user
            val query = dbkost.rawQuery("select * from user where username='$isi_username' and pswd_user='$isi_password'", null)
            val cek = query.moveToNext()

            //validasi jika username dan password benar atau tidak
            if(cek){
                val id_user= query.getString(0)
                val username= query.getString(1)
                val password= query.getString(2)

                val session:SharedPreferences = getSharedPreferences("user", MODE_PRIVATE)
                val buattiket = session.edit()
                buattiket.putString("id_user",id_user)
                buattiket.putString("username",username)
                buattiket.putString("pswd_user",password)
                buattiket.commit()
                //pindah ke halaman utama jika berhasil
                val pindah = Intent(this, Utama::class.java)
                startActivity(pindah)
                finish()
            }else{
                Toast.makeText(this,"Username atau Password anda salah!", Toast.LENGTH_LONG).show()
            }

        }
    }
}