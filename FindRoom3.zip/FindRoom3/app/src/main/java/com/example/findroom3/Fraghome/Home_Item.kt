package com.example.findroom3.Fraghome

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.findroom3.R  // Pastikan mengganti findroom1 menjadi findroom3 atau sesuai dengan paket aplikasi Anda

class Home_Item(
    val id: MutableList<String>,
    val nama: MutableList<String>,
    val kategori: MutableList<String>,
    val alamat: MutableList<String>,
    val harga: MutableList<String>,
    val fasilitas: MutableList<String>,
    val iduser: MutableList<String>,
    val foto: MutableList<Int>
) : RecyclerView.Adapter<Home_Item.ViewHolder>() {  // Ganti Favputra_Item.ViewHolder menjadi Home_Item.ViewHolder

    // Dapatkan layout
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.home_item, parent, false)
        return ViewHolder(view)
    }

    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val nm_kost: TextView = ItemView.findViewById(R.id.nm_kost)
        val kt_kost: TextView = ItemView.findViewById(R.id.kt_kost)
        val alamat_kost: TextView = ItemView.findViewById(R.id.alamat_kost)
        val harga_kost: TextView = ItemView.findViewById(R.id.harga_kost)
        val fasilitas_kost: TextView = ItemView.findViewById(R.id.fasilitas_kost)
        val foto_kost: ImageView = ItemView.findViewById(R.id.foto_kost)
    }

    override fun getItemCount(): Int {
        return nama.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.nm_kost.text = nama[position]
        holder.kt_kost.text = kategori[position]
        holder.alamat_kost.text = alamat[position]
        holder.harga_kost.text = harga[position]
        holder.fasilitas_kost.text = fasilitas[position]
        holder.foto_kost.setImageResource(foto[position])
    }
}
