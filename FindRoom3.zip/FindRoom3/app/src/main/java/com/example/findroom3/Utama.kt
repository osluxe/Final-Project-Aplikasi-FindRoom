package com.example.findroom3


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import androidx.fragment.app.FragmentContainerView
import com.example.findroom3.Chat
import com.example.findroom3.FragFavorit.Favorit
import com.example.findroom3.Home
import com.example.findroom3.Profil
import com.example.findroom3.R
import com.example.findroom3.Tambah


class Utama : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.utama)

        val btn_home:ImageView = findViewById(R.id.btn_home)
        val btn_chat:ImageView = findViewById(R.id.btn_chat)
        val btn_tambah:ImageView = findViewById(R.id.btn_tambah)
        val btn_favorit:ImageView = findViewById(R.id.btn_favorit)
        val btn_profil:ImageView = findViewById(R.id.btn_profil)
        val fc_konten:FragmentContainerView = findViewById(R.id.fc_konten)

        val fm = supportFragmentManager
        val ft = fm.beginTransaction()
        ft.replace(fc_konten.id, Home())
        ft.commit()

        btn_home.setOnClickListener {
            val fm = supportFragmentManager
            val ft = fm.beginTransaction()
            ft.replace(fc_konten.id, Home())
            ft.commit()
        }

        btn_chat.setOnClickListener {
            val fm = supportFragmentManager
            val ft = fm.beginTransaction()
            ft.replace(fc_konten.id, Chat())
            ft.commit()
        }

        btn_tambah.setOnClickListener {
            val fm = supportFragmentManager
            val ft = fm.beginTransaction()
            ft.replace(fc_konten.id, Tambah())
            ft.commit()
        }

        btn_favorit.setOnClickListener {
            val fm = supportFragmentManager
            val ft = fm.beginTransaction()
            ft.replace(fc_konten.id, Favorit())
            ft.commit()
        }

        btn_profil.setOnClickListener {
            val fm = supportFragmentManager
            val ft = fm.beginTransaction()
            ft.replace(fc_konten.id, Profil())
            ft.commit()
        }
    }
}