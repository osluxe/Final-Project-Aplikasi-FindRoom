package com.example.findroom3

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.LinearLayout

class MyKost_Ubah : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.mykost_ubah)

        // Dapatkan id_kost yang dipilih dari SharedPreferences
        val id_kost_terpilih: String = intent.getStringExtra("id_kost").toString()

        val dbkost: SQLiteDatabase = openOrCreateDatabase("findroom", Context.MODE_PRIVATE, null)
        val ambil = dbkost.rawQuery("SELECT * FROM kost WHERE id_kost ='$id_kost_terpilih'", null)
        ambil.moveToNext()

        val isi_namakost:String = ambil.getString(1)
        val isi_kategorikost:String = ambil.getString(2)
        val isi_alamatkost:String = ambil.getString(3)
        val isi_hargakost:String = ambil.getString(4)
        val isi_fasilitaskost:String = ambil.getString(5)

        val edt_namakost: EditText = findViewById(R.id.edt_namaKost)
        val edt_kategori: EditText = findViewById(R.id.edt_kategori)
        val edt_alamat: EditText = findViewById(R.id.edt_alamat)
        val edt_harga: EditText = findViewById(R.id.edt_harga)
        val edt_fasilitas: EditText = findViewById(R.id.edt_fasilitas)
        val btn_perbarui: LinearLayout = findViewById(R.id.btn_perbarui)

        edt_namakost.setText(isi_namakost)
        edt_kategori.setText(isi_kategorikost)
        edt_alamat.setText(isi_alamatkost)
        edt_harga.setText(isi_hargakost)
        edt_fasilitas.setText(isi_fasilitaskost)

        //btn simpan ditekan
        btn_perbarui.setOnClickListener {
            val namakost_baru: String = edt_namakost.text.toString()
            val kategorikost_baru: String = edt_kategori.text.toString()
            val alamatkost_baru: String = edt_alamat.text.toString()
            val hargakost_baru: String = edt_harga.text.toString()
            val fasilitaskost_baru: String = edt_fasilitas.text.toString()


            // Gunakan parameterized query untuk menghindari SQL injection
            val ngubah = dbkost.rawQuery("UPDATE kost SET nama_kost = '$namakost_baru', kategori_kost = '$kategorikost_baru', alamat_kost = '$alamatkost_baru', harga_kost = '$hargakost_baru', fasilitas_kost = '$fasilitaskost_baru' where id_kost = '$id_kost_terpilih'", null)
            ngubah.moveToNext()


            val pindah = Intent(this, MyKost::class.java)
            startActivity(pindah)

        }

        val btn_batal_perbarui: LinearLayout = findViewById(R.id.btn_batal_perbarui)
        btn_batal_perbarui.setOnClickListener {
            val pindah: Intent = Intent(this, MyKost::class.java)
            startActivity(pindah)
        }
    }
}