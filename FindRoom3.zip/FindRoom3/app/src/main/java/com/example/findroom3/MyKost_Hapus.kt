package com.example.findroom3

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MyKost_Hapus : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.my_kost_hapus)

        //dapatkan id kost yang akan dihapus
        val id_kost_terpilih :String = intent.getStringExtra("id_kost_terpilih").toString()

        val dbkost: SQLiteDatabase = openOrCreateDatabase("findroom", MODE_PRIVATE, null)

        val query = dbkost.rawQuery("delete from kost where id_kost = '$id_kost_terpilih'", null)
        query.moveToNext()

        val pindah:Intent = Intent(this, MyKost::class.java)
        startActivity(pindah)
    }
}