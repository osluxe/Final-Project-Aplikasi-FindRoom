package com.example.findroom3

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.findroom3.Fraghome.Home_Item

class MyKost_Item(
    val ini: Context,
    val id: MutableList<String>,
    val nama: MutableList<String>,
    val kategori: MutableList<String>,
    val alamat: MutableList<String>,
    val harga: MutableList<String>,
    val fasilitas: MutableList<String>,
    val iduser: MutableList<String>,
    val foto: MutableList<Int>
) : RecyclerView.Adapter<MyKost_Item.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyKost_Item.ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.my_kost_item, parent, false)
        return ViewHolder(view)
    }

    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val nm_kost: TextView = ItemView.findViewById(R.id.nm_kost)
        val kt_kost: TextView = ItemView.findViewById(R.id.kt_kost)
        val alamat_kost: TextView = ItemView.findViewById(R.id.alamat_kost)
        val harga_kost: TextView = ItemView.findViewById(R.id.harga_kost)
        val fasilitas_kost: TextView = ItemView.findViewById(R.id.fasilitas_kost)
        val foto_kost: ImageView = ItemView.findViewById(R.id.foto_kost)
        val btn_edit: ImageView = ItemView.findViewById(R.id.btn_edit)
        val btn_hapus: ImageView = ItemView.findViewById(R.id.btn_hapus)

    }
    override fun getItemCount(): Int {
        return nama.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.nm_kost.text = nama[position]
        holder.kt_kost.text = kategori[position]
        holder.alamat_kost.text = alamat[position]
        holder.harga_kost.text = harga[position]
        holder.fasilitas_kost.text = fasilitas[position]
        holder.foto_kost.setImageResource(foto[position])

        holder.btn_hapus.setOnClickListener {
            val pindah: Intent = Intent(ini, MyKost_Hapus::class.java)
            pindah.putExtra("id_kost_terpilih", id[position])
            ini.startActivity(pindah)
        }

        holder.btn_edit.setOnClickListener {
            val pindah: Intent = Intent(ini, MyKost_Ubah::class.java)
            pindah.putExtra("id_kost",id[position])
            ini.startActivity(pindah)
        }
    }
}